// project-imports
import ComingSoonPage from 'views/maintenance/ComingSoon';

// ==============================|| COMING SOON ||============================== //

export default function ComingSoon() {
  return <ComingSoonPage />;
}
