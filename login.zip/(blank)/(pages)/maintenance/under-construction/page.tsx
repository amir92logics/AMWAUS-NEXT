// project-imports
import UnderConstructionPage from 'views/maintenance/UnderConstruction';

// ==============================|| UNDER CONSTRUCTION ||============================== //

export default function UnderConstruction() {
  return <UnderConstructionPage />;
}
