"use client";

import Personal from 'sections/admin/dashboard';
// ==============================|| PROFILE - USER ||============================== //

const AdminProfile = () => <Personal />;

export default AdminProfile;